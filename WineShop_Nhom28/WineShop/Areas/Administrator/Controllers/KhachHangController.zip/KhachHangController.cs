﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WineShop.Models;
using PagedList;
using System.Net;
using System.Data.Entity;

namespace WineShop.Areas.Administrator.Controllers
{
    public class KhachHangController : Controller
    {
        ShopRuouDBEntities db = new ShopRuouDBEntities();
        // GET: Administrator/KhachHang
        public ActionResult Index(string sortOrder, string currentFilter, string TimKhachHang, int? page)
        {
            if (Session["DangNhapAdmin"] == null || !Session["DangNhapAdmin"].ToString().Equals("true"))
            {
                return RedirectToAction("Index", "DangNhap");
            }
            Session["a"] = "KhachHang";
            ViewBag.CurrentFilter = sortOrder;
            ViewBag.TenKhachHangs = string.IsNullOrEmpty(sortOrder) ? "khachhang" : "khachhang_desc";

            var kh = db.AspNetUsers.Where(h => h.LockoutEnabled == true && !h.Id.Equals("minda-admin-min-ad") );
      
            if (sortOrder != null && sortOrder.Equals("khachhang_desc"))
            {
                kh = kh.OrderByDescending(h => h.UserName);
            }
            else
            {
                kh = kh.OrderBy(h => h.UserName);
            }
            if (TimKhachHang != null)
            {
                page = 1;
            }
            else
            {
                TimKhachHang = currentFilter;
            }

            ViewBag.CurrentFilter = TimKhachHang;
            if (TimKhachHang != null)
            {
                kh = kh.Where(h => h.UserName.Contains(TimKhachHang.Trim()));
            }

            int pageSize = 5;
            int pageNumber = (page ?? 1);
            return View(kh.ToPagedList(pageNumber, pageSize));
        }
        public ActionResult PhanQuyen(string id)
        {
            if (Session["DangNhapAdmin"] == null || !Session["DangNhapAdmin"].ToString().Equals("true"))
            {
                return RedirectToAction("Index", "DangNhap");
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var kh = db.AspNetUsers.Single(u => u.Id.Equals(id));

            var role = db.AspNetRoles.ToList();
            List<AspNetRole> quyens = new List<AspNetRole>();
            foreach(var r in role)
            {
                if (!kh.AspNetRoles.Contains(r))
                {
                    quyens.Add(r);
                }
            }
            if(quyens.Count == 0)
            {
                return RedirectToAction("Index");
            }
            
            ViewBag.Quyens = new SelectList(quyens, "Id", "Name");
            return View(kh);
        }
        [HttpPost]
        public ActionResult PhanQuyen([Bind(Include = "Id")]AspNetUser user, string RoleID)
        {
            if (Session["DangNhapAdmin"] == null || !Session["DangNhapAdmin"].ToString().Equals("true"))
            {
                return RedirectToAction("Index", "DangNhap");
            }
            if (!ModelState.IsValid)
            {
                return View(user);
            }

           

            // có thể không cần truy vấn 2 dòng dưới
            
            var kh = db.AspNetUsers.Single(u => u.Id.Equals(user.Id));
            var tempRole = new AspNetRole
            {
                Id = RoleID
            };
            bool exists = kh.AspNetRoles.Contains(tempRole);
            if (exists)
            {
                return View(user);
            }
            // New class vừa tạo
            AspNetUserRoles a = new AspNetUserRoles();
            //kh.ID có thể truyền trực tiếp bằng mã/id không cần load từ Db Lên
            var khachhang = a.Users.Find(user.Id); //<<== Chỗ này
            var quyen = a.Roles.Find(RoleID);//<<== Chỗ này
            khachhang.AspNetRoles.Add(quyen);
            //class vừa tạo SaveChanges()
            if (a.SaveChanges() > 0)
            {
                return RedirectToAction("Index");
            }
            else
            {
                List<AspNetRole> listQuyen = db.AspNetRoles.ToList<AspNetRole>();
                ViewBag.Quyens = new SelectList(listQuyen, "Id", "Name");
                return View(user);
            }


        }
        public ActionResult HuyPhanQuyen(string id)
        {
            if (Session["DangNhapAdmin"] == null || !Session["DangNhapAdmin"].ToString().Equals("true"))
            {
                return RedirectToAction("Index", "DangNhap");
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var kh = db.AspNetUsers.Single(u => u.Id.Equals(id));
            List<AspNetRole> quyen = kh.AspNetRoles.ToList<AspNetRole>();
            ViewBag.Quyens = new SelectList(quyen, "Id", "Name");
            return View(kh);
        }
        [HttpPost]
        public ActionResult HuyPhanQuyen([Bind(Include = "Id")]AspNetUser user, string RoleID)
        {
            if (Session["DangNhapAdmin"] == null || !Session["DangNhapAdmin"].ToString().Equals("true"))
            {
                return RedirectToAction("Index", "DangNhap");
            }
            if (!ModelState.IsValid)
            {
                return View(user);
            }

            var kh = db.AspNetUsers.Single(u => u.Id.Equals(user.Id));
            
            // nếu 1 khách hàng chỉ còn 1 quyên thì không được xóa quyền nữa
            if (kh.AspNetRoles.Count == 1)
            {
                return RedirectToAction("Index");
            }
            AspNetUserRoles a = new AspNetUserRoles();
            var khachhang = a.Users.Find(user.Id);
            var quyen = a.Roles.Find(RoleID);
            khachhang.AspNetRoles.Remove(quyen);
            if (a.SaveChanges() > 0)
            {
                return RedirectToAction("Index");
            }
            else
            {
                List<AspNetRole> listQuyen = kh.AspNetRoles.ToList<AspNetRole>();
                ViewBag.Quyens = new SelectList(listQuyen, "Id", "Name");
                return View(user);
            }
        }

        public ActionResult Xoa([Bind(Include = "Id")]AspNetUser user)
        {
            if (Session["DangNhapAdmin"] == null || !Session["DangNhapAdmin"].ToString().Equals("true"))
            {
                return RedirectToAction("Index", "DangNhap");
            }
            if (!ModelState.IsValid)
            {
                return RedirectToAction("Index");
            }
            var kh = db.AspNetUsers.Single<AspNetUser>(h => h.Id.Equals(user.Id));
            
            var ddh = db.DonDatHangs.Find(kh.Id);
            if(ddh == null)
            {
                db.AspNetUsers.Remove(kh);
            }else
            {
                // nếu khách hàng có đơn hàng -> xóa ẩn
                kh.LockoutEnabled = false;
            }
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}